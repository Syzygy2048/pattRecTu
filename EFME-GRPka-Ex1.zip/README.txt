call main to execute all the code,
superscript shows the distribution of our 5 classes with all the attributes we chose
superscript2 performs the kNN on our 5 classes
superscript3 performs the finetuned classification algorithm